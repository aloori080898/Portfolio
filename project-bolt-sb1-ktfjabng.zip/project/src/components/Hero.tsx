import React from 'react';
import { Github, Linkedin, Mail } from 'lucide-react';

export function Hero() {
  return (
    <section id="about" className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-indigo-50 pt-16">
      <div className="max-w-6xl mx-auto px-4 py-20 flex flex-col md:flex-row items-center gap-12">
        <div className="flex-1 space-y-6">
          <h1 className="text-5xl font-bold text-gray-900">
            Hi, I'm Aloori Nagaraju
          </h1>
          <p className="text-xl text-gray-600">
            Data Analyst/Data Scientist/ Machine Leraning Engineer specializing in data processing, visualization,Deep Learning and Machine learning using Google Cloud Platform (GCP), SQL, Python, and Power BI.
          </p>
          <div className="flex gap-4">
            <a href="https://github.com/aloori080898" target="_blank" rel="noopener noreferrer" 
               className="p-2 text-gray-600 hover:text-gray-900">
              <Github size={24} />
            </a>
            <a href="www.linkedin.com/in/aloorinagaraju1623" target="_blank" rel="noopener noreferrer"
               className="p-2 text-gray-600 hover:text-gray-900">
              <Linkedin size={24} />
            </a>
            <a href="mailto:nagaraju.161998@gmail.com"
               className="p-2 text-gray-600 hover:text-gray-900">
              <Mail size={24} />
            </a>
          </div>
        </div>
        <div className="flex-1">
          <img 
            src="https://vui.unsplash.com/resize?height=256&quality=60&type=auto&url=https%3A%2F%2Fsearched-images.s3.us-west-2.amazonaws.com%2F54ccb5c7-5ffe-4025-8cf7-3f05bab3b66e%3FX-Amz-Algorithm%3DAWS4-HMAC-SHA256%26X-Amz-Credential%3DAKIAQ4GRIA4Q6TT7CKDU%252F20241224%252Fus-west-2%252Fs3%252Faws4_request%26X-Amz-Date%3D20241224T092638Z%26X-Amz-Expires%3D86400%26X-Amz-SignedHeaders%3Dhost%26X-Amz-Signature%3D114713c0a8fd07a97a3a26fca89a4e61f8532b6d79df65a47151f822d3e10952&sign=vZc4jUrdGsO7BCBsJ3wqEItZhgCCn_X3NkyhSCtIMkY" 
            alt="Profile" 
            className="rounded-full w-72 h-72 object-cover mx-auto shadow-xl"
          />
        </div>
      </div>
    </section>
  );
}