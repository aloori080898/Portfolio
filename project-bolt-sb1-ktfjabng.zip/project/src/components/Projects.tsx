import React from 'react';

const projects = [
  {
    id: 1,
    title: 'Comparison of Machine Learning Algorithms for Predicting Chronic Kidney Disease',
    description: 'comparative analysis of machine learning algorithms for predicting Chronic Kidney Disease (CKD) using clinical and laboratory datasets. Algorithms such as Logistic Regression, Decision Trees, Random Forest, Support Vector Machines (SVM), and k-Nearest Neighbors (k-NN) are evaluated based on performance metrics, including accuracy, precision, recall, F1-score, and ROC-AUC.',
    image: 'https://vui.unsplash.com/resize?height=256&quality=60&type=auto&url=https%3A%2F%2Fsearched-images.s3.us-west-2.amazonaws.com%2F040e3fb4-74eb-4522-95ba-99912b20994c%3FX-Amz-Algorithm%3DAWS4-HMAC-SHA256%26X-Amz-Credential%3DAKIAQ4GRIA4Q6TT7CKDU%252F20241224%252Fus-west-2%252Fs3%252Faws4_request%26X-Amz-Date%3D20241224T100844Z%26X-Amz-Expires%3D86400%26X-Amz-SignedHeaders%3Dhost%26X-Amz-Signature%3D9dabf52c85408282bb87e8a59605494141ad0d10fb2530c50bfb00612c842410&sign=fgLHiWuBnaOKP3Urk7WufDW2CVpZtOtckw5ZQWeq59M',
    link: 'https://github.com/aloori080898/CKD_machine_learning_algorithm_compardion'
  },
  {
    id: 2,
    title: 'Customer Churn Analysis Dashboard',
    description: 'Analyzed and visualized customer churn data to identify key factors influencing customer retention. Used Power BI to create interactive dashboards displaying churn rates, customer demographics, usage patterns, and predictive models.',
    image: 'https://vui.unsplash.com/resize?height=256&quality=60&type=auto&url=https%3A%2F%2Fdaxg39y63pxwu.cloudfront.net%2Fimages%2Fblog%2Fchurn-models%2FCustomer_Churn_Prediction_Models_in_Machine_Learning.png&sign=iwOTB5Q5rHeIIDkM8OWI5LaIKqq1RO5k9IUuIKE4lxc',
    link: 'https://github.com/aloori080898/aloori080898/blob/main/Customer%20Churn%20Analysis.pbix'
  },
  {
    id: 3,
    title: 'Visual_tracking_system',
    description: 'A Visual Tracking System in Python leverages ,computer vision and machine learning algorithms to detect, track, and analyze objects in real time using libraries like OpenCV and TensorFlow. It is designed for applications such as surveillance, motion analysis, and autonomous navigation, enabling accurate and efficient object monitoring and movement prediction.',
    image: 'https://vui.unsplash.com/resize?height=256&quality=60&type=auto&url=https%3A%2F%2Fsearched-images.s3.us-west-2.amazonaws.com%2Ff475fbf5-e46f-49a1-854d-ba4ab112bccc%3FX-Amz-Algorithm%3DAWS4-HMAC-SHA256%26X-Amz-Credential%3DAKIAQ4GRIA4Q6TT7CKDU%252F20241224%252Fus-west-2%252Fs3%252Faws4_request%26X-Amz-Date%3D20241224T102654Z%26X-Amz-Expires%3D86400%26X-Amz-SignedHeaders%3Dhost%26X-Amz-Signature%3D68dc6dfc642f25073b728dacab71764005ff11657aaba81a74f0bea81f87183b&sign=sbiHLwtAUgX15cRpwzGNxVA-e4CD0JfeMSdxFk8IMJA',
    link: 'https://github.com/aloori080898/Visual_tracking_system.python'
  },
  {
    id: 4,
    title: 'Call Center Analytics Dashboard',
    description: 'A comprehensive Power BI dashboard for call center analytics featuring real-time KPI tracking, agent performance metrics, call volume trends, and customer satisfaction scores.',
    image: 'https://vui.unsplash.com/resize?height=256&quality=60&type=auto&url=https%3A%2F%2Fsearched-images.s3.us-west-2.amazonaws.com%2F3434b194-0cda-447a-af84-b52817ff0a24%3FX-Amz-Algorithm%3DAWS4-HMAC-SHA256%26X-Amz-Credential%3DAKIAQ4GRIA4Q6TT7CKDU%252F20241224%252Fus-west-2%252Fs3%252Faws4_request%26X-Amz-Date%3D20241224T094255Z%26X-Amz-Expires%3D86400%26X-Amz-SignedHeaders%3Dhost%26X-Amz-Signature%3D7b7545e8b9413609b59706bb197d7c41ed15ad0103213fb53f636d36792a66a9&sign=_9HcBYJSNaA8eLYhAwPsj1N-iG8p_SfAeIYP_QiDPKU',
    link: 'https://github.com/aloori080898/call-center-dashboard'
  },
  {
    id: 5,
    title: 'E-commerce',
    description: 'E-commerce enhances customer experiences and business performance through personalized recommendations,dynamic pricing, demand forecasting, and fraud detection.Algorithms analyze customer behavior, preferences, and purchase history to predict trends, optimize inventory, and improve marketing strategies.',
    image: 'https://vui.unsplash.com/resize?height=256&quality=60&type=auto&url=https%3A%2F%2Fsearched-images.s3.us-west-2.amazonaws.com%2Fff36af16-394d-4242-948a-5638b42badc2%3FX-Amz-Algorithm%3DAWS4-HMAC-SHA256%26X-Amz-Credential%3DAKIAQ4GRIA4Q6TT7CKDU%252F20241224%252Fus-west-2%252Fs3%252Faws4_request%26X-Amz-Date%3D20241224T125110Z%26X-Amz-Expires%3D86400%26X-Amz-SignedHeaders%3Dhost%26X-Amz-Signature%3D26959c5e71c651e6d5d00036d152fba458434b70cfc138bd8e0a69b318924938&sign=S4Q9jFvEjAGRlU7-mQjnaL05hAKcPFWpfq4wlSye0RU',
    link: 'https://github.com/aloori080898/sql-python-ecommerce-project/tree/main'
  },
  {
    id: 6,
    title: 'Food Delivery Cost Analysis',
    description: 'Food Delivery Cost Analysis using machine learning focuses on optimizing delivery operations by analyzing factors such as distance, time, traffic patterns, order size, delivery zones, and driver availability. Algorithms like Linear Regression, Decision Trees, and Gradient Boosting predict delivery costs, helping businesses streamline pricing strategies and reduce operational expenses.',
    image: 'https://vui.unsplash.com/resize?height=256&quality=60&type=auto&url=https%3A%2F%2Fsearched-images.s3.us-west-2.amazonaws.com%2F37bd4d9a-4e64-4a0e-ba80-d3b8e793b03a%3FX-Amz-Algorithm%3DAWS4-HMAC-SHA256%26X-Amz-Credential%3DAKIAQ4GRIA4Q6TT7CKDU%252F20241224%252Fus-west-2%252Fs3%252Faws4_request%26X-Amz-Date%3D20241224T125927Z%26X-Amz-Expires%3D86400%26X-Amz-SignedHeaders%3Dhost%26X-Amz-Signature%3D84d15f12f389d0af4f38124fd9a62de49eb7ee047dde5f125b814201f2db12a1&sign=RXVzxmHy-6lX_g2KlxqY-EY-CrpUN7z-chuKOgef1rw',
    link: 'https://github.com/aloori080898/Food-delivery-costs-analysis'
  },
  {
    id: 7,
    title: 'Diwali Sales Analysis',
    description: 'Diwali Sales Analysis using machine learning leverages historical sales data to identify patterns, trends, and customer preferences during the festive season. Techniques such as Regression Analysis, Time Series Forecasting, and Clustering Algorithms predict sales performance, optimize inventory management.',
    image: 'https://vui.unsplash.com/resize?height=256&quality=60&type=auto&url=https%3A%2F%2Fsearched-images.s3.us-west-2.amazonaws.com%2F4fe35b6f-2f76-4a99-b8d3-b0e023b586b1%3FX-Amz-Algorithm%3DAWS4-HMAC-SHA256%26X-Amz-Credential%3DAKIAQ4GRIA4Q6TT7CKDU%252F20241224%252Fus-west-2%252Fs3%252Faws4_request%26X-Amz-Date%3D20241224T130829Z%26X-Amz-Expires%3D86400%26X-Amz-SignedHeaders%3Dhost%26X-Amz-Signature%3Df4bd585ca68c7fc45a6e1ecd56b59fbef0c6788078138591421d09259e47fb3d&sign=fUvUX5gIEfrO8f1PG4-n2rOsMuJ_j3YsgnyxIj4v_AU',
    link: 'https://github.com/aloori080898/Diwali_sales_analysis'
  },
  {
    id: 8,
    title: 'HR Analytics Dashboard',
    description: 'Interactive HR Analytics Dashboard using Power BI to visualize critical workforce metrics and trends. Features employee demographics, retention rates, performance, and engagement metrics.',
    image: 'https://vui.unsplash.com/resize?height=256&quality=60&type=auto&url=https%3A%2F%2Fsearched-images.s3.us-west-2.amazonaws.com%2F0894049f-581d-4ae9-b27c-8124f3fc2e1e%3FX-Amz-Algorithm%3DAWS4-HMAC-SHA256%26X-Amz-Credential%3DAKIAQ4GRIA4Q6TT7CKDU%252F20241224%252Fus-west-2%252Fs3%252Faws4_request%26X-Amz-Date%3D20241224T093201Z%26X-Amz-Expires%3D86400%26X-Amz-SignedHeaders%3Dhost%26X-Amz-Signature%3D28e9ee3e851f71c4372dde5ab9db240bb7fe2c41085444ccccc8f136ef2816c0&sign=mg6mBRCqJG2XQRNYUHp38vDtc-M8ZLo3vwE4XgFhmD0',
    link: 'https://github.com/aloori080898/aloori080898/blob/main/HR%20analyst%20project.pbix'
  }
];

export function Projects() {
  return (
    <section id="projects" className="py-20 bg-gray-50">
      <div className="max-w-6xl mx-auto px-4">
        <h2 className="text-3xl font-bold text-center mb-12">Projects</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {projects.map((project) => (
            <a
              key={project.id}
              href={project.link}
              className="block group bg-white rounded-lg overflow-hidden shadow-lg hover:shadow-xl transition-shadow"
              target="_blank"
              rel="noopener noreferrer"
            >
              <div className="aspect-video overflow-hidden">
                <img
                  src={project.image}
                  alt={project.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                />
              </div>
              <div className="p-6">
                <h3 className="text-xl font-semibold mb-2">{project.title}</h3>
                <p className="text-gray-600 line-clamp-3">{project.description}</p>
              </div>
            </a>
          ))}
        </div>
      </div>
    </section>
  );
}